#pragma once

// Öffentliche UI-Funktionen
void drawUI();
